# IoT-216_prac1
Mission: 
* 데이터베이스 생성 및 연결 - sqlConnection, sqlCommand
* 텍스트박스를 통해 sql문 받고 실행 - ExecuteNonQuery(), ExecuteReader()
* 질의문(select)결과를 DataGridView에 나타내기
